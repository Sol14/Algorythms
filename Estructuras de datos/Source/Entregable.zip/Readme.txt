La vez pasada se me olvido enviar el documento PDF por estar distraido
creo que esta vez va todo la ultima entrega tenía la foto en la bibliografía
pero LaTEX me la volvió roja, esta vez no modifiqué el codigo de la foto pero
ya no me aparece del todo, así que realmente no se como esta funcionando eso
